local hide_words =
{ 	["示~例~"] = { "shil", "shili", },
	["么特瑞"] = { "meter", },
}
return hide_words